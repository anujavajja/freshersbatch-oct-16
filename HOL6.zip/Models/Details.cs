﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Day6MvcApp.Models
{
    public class Details
    {
        public int a { get; set; }
    }
}