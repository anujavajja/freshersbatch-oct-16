﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HANDS_ON_LAB.Controllers
{
    public class ProductController : Controller
    {
        public ActionResult Index()
        {

            Models.Product p = new Models.Product();

            //pass a list of products to the view
            return View(p.GetProducts());
        }
    }

}